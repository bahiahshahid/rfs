<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * ApplicationsFixture
 */
class ApplicationsFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'lecturer_id' => 1,
                'title' => 'Lorem ipsum dolor sit amet',
                'budget' => 1,
                'start_date' => '2025-06-29 18:15:50',
                'end_date' => '2025-06-29 18:15:50',
                'abstract' => 'Lorem ipsum dolor sit amet',
                'literature_review' => 'Lorem ipsum dolor sit amet',
                'member_1' => 'Lorem ipsum dolor sit amet',
                'member_2' => 'Lorem ipsum dolor sit amet',
                'member_3' => 'Lorem ipsum dolor sit amet',
                'member_4' => 'Lorem ipsum dolor sit amet',
                'member_5' => 'Lorem ipsum dolor sit amet',
                'approval_name' => 'Lorem ipsum dolor sit amet',
                'approval_post' => 'Lorem ipsum dolor sit amet',
                'approval_date' => '2025-06-29 18:15:50',
                'status' => 1,
                'application_date' => '2025-06-29 18:15:50',
                'created' => '2025-06-29 18:15:50',
                'modified' => '2025-06-29 18:15:50',
            ],
        ];
        parent::init();
    }
}
