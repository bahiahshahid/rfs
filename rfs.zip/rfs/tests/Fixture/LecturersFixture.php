<?php
declare(strict_types=1);

namespace App\Test\Fixture;

use Cake\TestSuite\Fixture\TestFixture;

/**
 * LecturersFixture
 */
class LecturersFixture extends TestFixture
{
    /**
     * Init method
     *
     * @return void
     */
    public function init(): void
    {
        $this->records = [
            [
                'id' => 1,
                'department_id' => 1,
                'branch_id' => 1,
                'salutation' => 'Lorem ipsum dolor sit amet',
                'name' => 'Lorem ipsum dolor sit amet',
                'staff_no' => 1,
                'status' => 1,
                'created' => '2025-06-29 18:15:05',
                'modified' => '2025-06-29 18:15:05',
            ],
        ];
        parent::init();
    }
}
