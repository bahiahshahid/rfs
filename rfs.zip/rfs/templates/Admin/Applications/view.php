<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Application $application
 */
?>
<!--Header-->
<div class="row text-body-secondary">
    <div class="col-10">
        <h1 class="my-0 page_title"><?php echo $title; ?></h1>
        <h6 class="sub_title text-body-secondary"><?php echo $system_name; ?></h6>
    </div>
    <div class="col-2 text-end">
        <div class="dropdown mx-3 mt-2">
            <button class="btn p-0 border-0" type="button" id="orederStatistics" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <i class="fa-solid fa-bars text-primary"></i>
            </button>
            <div class="dropdown-menu dropdown-menu-end" aria-labelledby="orederStatistics">
                <li><?= $this->Html->link(__('Edit Application'), ['action' => 'edit', $application->id], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
                <li><?= $this->Form->postLink(__('Delete Application'), ['action' => 'delete', $application->id], ['confirm' => __('Are you sure you want to delete # {0}?', $application->id), 'class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
                <li>
                    <hr class="dropdown-divider">
                </li>
                <li><?= $this->Html->link(__('Download PDF'), ['action' => 'pdf', $application->id], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
                <li>
                    <hr class="dropdown-divider">
                </li>
                <li><?= $this->Html->link(__('List Applications'), ['action' => 'index'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
                <li><?= $this->Html->link(__('New Application'), ['action' => 'add'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?></li>
            </div>
        </div>
    </div>
</div>
<div class="line mb-4"></div>

<!--/pdf--->
<div class="row">
    <div class="col-md-9">
        <div class="card rounded-0 mb-3 bg-body-tertiary border-0 shadow">
            <div class="card-body text-body-secondary">
                <style>
                    .capital {
                        text-transform: uppercase;
                    }

                    .justify {
                        text-align: justify;
                    }

                    .top {
                        width: 100%;
                        margin: auto;
                    }

                    .one {
                        width: 72%;
                        height: 25px;
                        background: #292983;
                        float: left;
                    }

                    .two {
                        margin-left: 15%;
                        height: 25px;
                        background: #912890;
                    }
                </style>


                <section class="top">
                    <div class="one"></div>
                    <div class="two"></div>
                </section>

                <div class="text-end my-4 me-5">
                    <?php echo $this->Html->image('../img/surat/LogoUiTM.png', ['width' => '220px']) ?>
                </div>

                <hr />
                <table width="100%">
                    <tr>
                        <td width="78%" class="text-end">Surat Kami &nbsp;: &nbsp;</td>
                        <td>
                            <?php if ($application->status == 0) {
                                echo '-';
                            } elseif ($application->status == 1) {
                                echo $application->ref_no;
                            } else
                                echo 'Rejected';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-end">Tarikh &nbsp;: &nbsp;</td>
                        <td>
                            <?php if ($application->status == 0) {
                                echo '-';
                            } elseif ($application->status == 1) {
                                echo date('d F Y', strtotime($application->created));
                            } else
                                echo 'Rejected';
                            ?>
                        </td>
                    </tr>
                </table>

                <?php echo $application->lecturer->name; ?><br/>
                Pensyarah<br/>
                Fakulti Sains Maklumat</br>
                UiTM Cawangan Selangor Kampus Puncak Perdana<br/>
                Jalan Pulau Indah Au10/A, Puncak Perdana, <br/>
                40150 Shah Alam, <br/>
                <strong>Selangor</strong>

                <br /><br />
                <b>Untuk Perhatian: <?= h($application->approval_name) ?></b>
                <br /><br />
                Tuan/Puan
                <br /><br />
                <strong>PERMOHONAN DANA PENYELIDIKAN</strong>
                <br /><br />
                <table class="table table-bordered table-sm table_transparent capital">
                    <tr>
                        <td>NAMA PENSYARAH</td>
                        <td>:</td>
                        <td><?= $application->lecturer->name ?></td>
                    </tr>
                    <tr>
                        <td>PROJEK</td>
                        <td>:</td>
                        <td><?= $application->title ?></td>
                    </tr>
                    <tr>
                        <td>BAJET</td>
                        <td>:</td>
                        <td><?= $application->budget ?></td>
                    </tr>
                    <tr>
                        <td>AHLI PERTAMA</td>
                        <td>:</td>
                        <td><?= h($application->member_1) ?></td>
                    </tr>
                    <tr>
                        <td>AHLI KEDUA</td>
                        <td>:</td>
                        <td><?= h($application->member_2) ?></td>
                    </tr>
                    <tr>
                        <td>AHLI KETIGA</td>
                        <td>:</td>
                        <td><?= h($application->member_3) ?></td>
                    </tr>
                    <tr>
                        <td>AHLI KEEMPAT</td>
                        <td>:</td>
                        <td><?= h($application->member_4) ?></td>
                    </tr>
                    <tr>
                        <td>AHLI KELIMA</td>
                        <td>:</td>
                        <td><?= h($application->member_5) ?></td>
                    </tr>
                </table>
                <br />
                <div class="justify">
                    Dengan segala hormatnya perkara di atas adalah dirujuk.
                    <br><br>
                    2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sukacita dimaklumkan bahawa saya, <?= $application->lecturer->name ?> dari Fakulti Sains Maklumat, ingin memohon dana penyelidikan bagi melaksanakan projek bertajuk:
                    <br><br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?= $application->title ?>
                    <br><br>
                    3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Penyelidikan ini bertujuan untuk menjalankan penyelidikan yang menyumbang kepada penambahan ilmu baharu dalam bidang sains maklumat. Kajian ini dijangka akan memberi sumbangan kepada bidang Fakulti Sains Maklumat serta menyokong agenda penyelidikan universiti.
                    <br><br>
                    Bersama-sama ini saya sertakan:
                    <ol type="a">
                        <li>&nbsp;&nbsp;&nbsp;&nbsp;Kertas cadangan penyelidikan</li>
                        <li>&nbsp;&nbsp;&nbsp;&nbsp;Anggaran bajet keseluruhan</li>
                        <li>&nbsp;&nbsp;&nbsp;&nbsp;Nama-nama ahli penyelidik</li>
                    </ol>
                    4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sehubungan itu, saya memohon pertimbangan pihak tuan/puan untuk meluluskan permohonan dana sebanyak RM <?= $application->budget ?> bagi tujuan penyelidikan ini. Peruntukan tersebut akan digunakan bagi perbelanjaan seperti pembelian bahan, perisian, data, upah penyelidik pembantu dan perjalanan.
                    <br><br>
                    5.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kerjasama dan pertimbangan pihak tuan/puan amat dihargai dan didahului dengan ucapan terima kasih.

                    <br><br>
                    <table width="100%">
                        <tr>
                            <td width="80%" style="vertical-align: top;">
                                Sekian, terima kasih.
                                <br><br>
                                <?php if ($application->status == 0) {
                                    echo '<b class="text-danger">[Dalam proses semakan]</strong>';
                                } elseif ($application->status == 1) {
                                    echo 'Jabatan Hal Ehwal Akademik, UiTM
                                <br><br>
                                <strong>CETAKAN BERKOMPUTER. TIDAK PERLU TANDATANGAN.</strong>';
                                } else
                                    echo 'Rejected';
                                ?>

                            </td>
                            <td class="text-end">
                                <?php if ($application->status == 1) { ?>
                                    <div id="qr" align="center"></div>
                                    <script type="text/javascript">
                                        const qrCode = new QRCodeStyling({
                                            width: 130,
                                            height: 130,
                                            margin: 0,
                                            //type: "svg",
                                            data: "<?php echo $this->request->getUri(); ?>",
                                            dotsOptions: {
                                                //color: "#4267b2",
                                                type: "dots"
                                            },
                                            cornersSquareOptions: {
                                                type: "dots",
                                                color: "#007bff",
                                            },
                                            cornersDotOptions: {
                                                type: "dots"
                                            },
                                            backgroundOptions: {
                                                //color: "#ffffff",
                                            },
                                            imageOptions: {
                                                crossOrigin: "anonymous",
                                                margin: 20
                                            }
                                        });

                                        qrCode.append(document.getElementById("qr"));
                                        //qrCode.download({ name: "qr", extension: "png" });
                                    </script>
                                <?php } ?>
                            </td>
                        </tr>
                    </table>
                    <hr />
                    <div class="text-end my-4 me-5">
                        <?php echo $this->Html->image('../img/surat/ISO.png', ['width' => '170px']) ?><br />
                        <?php echo $this->Html->image('../img/surat/uitmdihatiku.png', ['width' => '170px']) ?>
                    </div>
                </div>
            </div>
        </div>
    </div>


        <!--sidebar-->
<div class="col-md-3">
    <!-- Application Data -->
    <div class="card shadow border-0 gradient-border bg-body-tertiary mb-4">
        <div class="card-body">
            <div class="card-title mb-0">Application Data</div>
            <div class="tricolor_line mb-3"></div>
            <div class="table-responsive">
                <table class="table tabe-sm table-hover">
                    <tr>
                        <td>Application Date</td>
                        <td><?= date('M d, Y (h:i A)', strtotime($application->created)) ?></td>
                    </tr>
                    <tr>
                        <td>Approval Date</td>
                        <td><?= date('M d, Y (h:i A)', strtotime($application->modified)) ?></td>
                    </tr>
                    <tr>
                        <td>Application Status</td>
                        <td>
                            <?php
                            switch ($application->status) {
                                case 0: echo '<span class="badge bg-warning">Pending</span>'; break;
                                case 1: echo '<span class="badge bg-success">Approved</span>'; break;
                                case 2: echo '<span class="badge bg-danger">Rejected</span>'; break;
                                default: echo '<span class="badge bg-danger">Error</span>';
                            }
                            ?>
                        </td>
                    </tr>
                </table>
            </div>

            <?= $this->Form->create($application) ?>
            <?= $this->Form->control('status', ['options' => ['1'=>'Approved','2'=>'Reject'], 'class'=>'form-select','empty'=>'Select Action']) ?>
            <div class="text-end mt-3">
                <?php if ($application->status == 1): ?>
                    <?= $this->Html->link(__('Download PDF'), ['action'=>'pdf',$application->id], ['class'=>'btn btn-outline-primary']) ?>
                <?php endif; ?>
                <?= $this->Form->button(__('Reset'), ['type'=>'reset','class'=>'btn btn-outline-warning']) ?>
                <?= $this->Form->button(__('Submit'), ['type'=>'submit','class'=>'btn btn-outline-primary']) ?>
            </div>
            <?= $this->Form->end() ?>
        </div>
    </div>

    <!-- Member's Details -->
    <div class="card shadow border-0 gradient-border bg-body-tertiary mb-4">
        <div class="card-body">
            <div class="card-title mb-0">Member's Details</div>
            <div class="tricolor_line mb-3"></div>
            <table class="table table-sm table-borderless mb-0 table_transparent">
                <tr><th><?= __('Lecturer') ?></th><td><?= $application->hasValue('lecturer') ? $this->Html->link($application->lecturer->name, ['controller'=>'Lecturers','action'=>'view',$application->lecturer->id]) : '' ?></td></tr>
                <tr><th><?= __('Member 1') ?></th><td><?= h($application->member_1) ?></td></tr>
                <tr><th><?= __('Member 2') ?></th><td><?= h($application->member_2) ?></td></tr>
                <tr><th><?= __('Member 3') ?></th><td><?= h($application->member_3) ?></td></tr>
                <tr><th><?= __('Member 4') ?></th><td><?= h($application->member_4) ?></td></tr>
                <tr><th><?= __('Member 5') ?></th><td><?= h($application->member_5) ?></td></tr>
            </table>
        </div>
    </div>

    <!-- Research Fund's Details -->
    <div class="card shadow border-0 gradient-border bg-body-tertiary mb-4">
        <div class="card-body">
            <div class="card-title mb-0">Research Fund's Details</div>
            <div class="tricolor_line mb-3"></div>
            <table class="table table-sm table-borderless mb-0 table_transparent">
                <tr><th><?= __('Title') ?></th><td><?= h($application->title) ?></td></tr>
                <tr><th><?= __('Budget') ?></th><td><?= $this->Number->format($application->budget) ?></td></tr>
                <tr><th><?= __('Abstract') ?></th><td><?= h($application->abstract) ?></td></tr>
                <tr><th><?= __('Literature Review') ?></th><td><?= h($application->literature_review) ?></td></tr>
                <tr><th><?= __('Start Date') ?></th><td><?= h($application->start_date) ?></td></tr>
                <tr><th><?= __('End Date') ?></th><td><?= h($application->end_date) ?></td></tr>
            </table>
        </div>
    </div>

    <!-- Approval's Details -->
    <div class="card shadow border-0 gradient-border bg-body-tertiary mb-4">
        <div class="card-body">
            <div class="card-title mb-0">Approval's Details</div>
            <div class="tricolor_line mb-3"></div>
            <table class="table table-sm table-borderless mb-0 table_transparent">
                <tr><th><?= __('Approval Name') ?></th><td><?= h($application->approval_name) ?></td></tr>
                <tr><th><?= __('Approval Post') ?></th><td><?= h($application->approval_post) ?></td></tr>
                <tr><th><?= __('Approval Date') ?></th><td><?= h($application->approval_date) ?></td></tr>
            </table>
        </div>
    </div>
</div>
</div>

<!--Charts-->
    <div class="container">
    <div class="row py-3">
			<div class="col-4 text-start">
				<button class="btn btn-xs btn-outline-warning me-2" data-bs-toggle="collapse" href="#chartCollapse" role="button" aria-expanded="true" aria-controls="chartCollapse">
					Hide Chart
				</button>
				<button onClick="window.location.reload();" class="btn btn-xs btn-primary">Refresh</button>

			</div>
		</div>
    </div>

    <div class="collapse show" id="chartCollapse">
    <div class="container mt-4">
      <div class="row">
        <div class="col-md-4">
          <div class="card shadow bg-body-tertiary border-0">
            <div class="card-body">
              <h5 class="card-title mb-3">Project Status Summary</h5>
              <div>
                <canvas id="chart1" width="300" height="300"></canvas>

                <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

                <script>
  const chart1 = document.getElementById('chart1');

  new Chart(chart1, {
    type: 'bar',
    data: {
      labels: ['Jan', 'Feb', 'Mar', 'April', 'Jun'],
      datasets: [{
        label: 'Project Status Summary',
        data: [5.2, 6.1, 7.3, 7.8, 8.0, 8.2],
        backgroundColor: '#dc51c2',
        borderWidth: 1,
        hoverOffset: 15,
        hoverBorderColor: '#F9FAFB'
      }]
    },
    options: {
      maintainAspectRatio: false,
      scales: {
        y: {
          beginAtZero: true
        }
      }
    }
  });
</script>
    </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card shadow bg-body-tertiary border-0">
            <div class="card-body">
              <h5 class="card-title mb-3">Project by Faculty</h5>
              <div>
                  <canvas id="chart2" width="300" height="300"></canvas>
                  <script>
                const chart2 = document.getElementById('chart2');

                new Chart(chart2, {
                  type: 'line',
                  data: {
                    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
                    datasets: [{
                      label: 'Project by Faculty',
                      data: [12000, 15000, 18000, 21000, 23000, 24500],
                      borderColor: '#4e73df',
                      borderWidth: 1,
                      hoverOffset: 15,
                      hoverBorderColor: '#F9FAFB',
                      tension: 0.3,
                      fill: true,
                      backgroundColor: 'rgba(78, 115, 223, 0.05)'
                    }]
                  },
                  options: {
                    maintainAspectRatio: false,
                    scales: {
                      y: {
                        beginAtZero: true
                      }
                    }
                  }
                });
              </script>
                  </div>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card shadow bg-body-tertiary border-0">
            <div class="card-body">
              <h5 class="card-title mb-3">Lecturer Contribution</h5>
              <div>
                  <canvas id="chart3" width="300" height="300"></canvas>
                  <script>
                const chart3 = document.getElementById('chart3');

                new Chart(chart3, {
                  type: 'doughnut',
                  data: {
                    labels: ['Asyraf Wahi Anuar', 'Rabiatul Adawiyah binti Kamalruzaman', 'Abu bin Abi', 'Aisyah binti Rahman', 'Ridwan bin Seman'],
                    datasets: [{
                      label: 'Lecturer Contribution',
                      data: [35, 20, 15, 20, 10],
                      backgroundColor: ['#EC4899', '#3B82F6', '#F59E0B', '#8B5CF6', '#10B981'],
                      borderWidth: 1,
                      hoverOffset: 15,
                      hoverBorderColor: '#F9FAFB'
                    }]
                  },
                  options: {
                    maintainAspectRatio: false,
                    scales: {
                      y: {
                        beginAtZero: true
                      }
                    }
                  }
                });
              </script>
                  </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>

