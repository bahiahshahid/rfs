<?php
/**
 * @var \App\View\AppView $this
 * @var \App\Model\Entity\Application $application
 * @var \Cake\Collection\CollectionInterface|string[] $lecturers
 */
?>
<!--Header-->
<div class="row text-body-secondary">
	<div class="col-10">
		<h1 class="my-0 page_title"><?php echo $title; ?></h1>
		<h6 class="sub_title text-body-secondary"><?php echo $system_name; ?></h6>
	</div>
	<div class="col-2 text-end">
		<div class="dropdown mx-3 mt-2">
			<button class="btn p-0 border-0" type="button" id="orederStatistics" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
			<i class="fa-solid fa-bars text-primary"></i>
			</button>
				<div class="dropdown-menu dropdown-menu-end" aria-labelledby="orederStatistics">
            <?= $this->Html->link(('List Applications'), ['action' => 'index'], ['class' => 'dropdown-item', 'escapeTitle' => false]) ?>
				</div>
		</div>
    </div>
</div>
<div class="line mb-4"></div>
<!--/Header-->

<div class="card rounded-0 mb-3 bg-body-tertiary border-0 shadow">
    <div class="card-body text-body-secondary">

        <div class="card-title mb-0 mt-3">Reserach Details</div>
        <div class="tricolor_line mb-3"></div>
        
            <?= $this->Form->create($application, ['type' => 'file']) ?>
            <fieldset>

                    <div class="row">
                        <div class="col-md-6">
                            <?php echo $this->Form->control('lecturer_id', [
                                'options' => $lecturers, 
                                'empty' => 'Select Lecturer',
                                'class' => 'form-select'
                                ]); ?>
                        </div>
                        <div class="col-md-6">
                            <?php echo $this->Form->control('title'); ?>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <?php echo $this->Form->control('budget'); ?>
                        </div>
                        <div class="col-md-4">
                            <?php echo $this->Form->control('start_date'); ?>
                        </div>
                        <div class="col-md-4">
                            <?php echo $this->Form->control('end_date'); ?>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-6">
                            <?php echo $this->Form->control('abstract'); ?>
                        </div>
                        <div class="col-md-6">

                    <div class="row">
                        <div class="col-md-12">
                            <div class="mb-3">
                                <label class="form-label">Upload Literature Review</label>
                                <?php echo $this->Form->control('literature_review', [
                                    'type' => 'file',
                                    'label' => false,
                                    'class' => 'form-control'
                                ]); ?>
                            </div>
                        </div>
                    </div>


                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <?php echo $this->Form->control('member_1'); ?>
                        </div>
                        <div class="col-md-4">
                            <?php echo $this->Form->control('member_2'); ?>
                        </div>
                        <div class="col-md-4">
                            <?php echo $this->Form->control('member_3'); ?>
                        </div>
                    </div>
                    
                    <div class="row">
                        <div class="col-md-4">
                            <?php echo $this->Form->control('member_4'); ?>
                        </div>
                        <div class="col-md-4">
                            <?php echo $this->Form->control('member_5'); ?>
                        </div>
                        <div class="col-md-4">
                            <?php echo $this->Form->control('application_date'); ?>
                        </div>
                    </div>
                    
               
            </fieldset>
				<div class="text-end">
				  <?= $this->Form->button('Reset', ['type' => 'reset', 'class' => 'btn btn-outline-warning']); ?>
				  <?= $this->Form->button(('Submit'),['type' => 'submit', 'class' => 'btn btn-outline-primary']) ?>
                </div>
        <?= $this->Form->end() ?>
    </div>
</div>