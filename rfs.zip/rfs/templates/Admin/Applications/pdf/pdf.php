<!DOCTYPE html>
<html>

<head>
    <title>PDF</title>
    <style>
        @page {
            margin: 0px 0px 0px 0px !important;
            padding: 0px 0px 0px 0px !important;
        }

        .right {
            text-align: right;
            padding-right: 50px;
        }

        body {
            font-family: Arial, Helvetica, sans-serif;
            font-size: 13px;
        }

        .content {
            margin-left: 70px;
            margin-right: 70px;
        }

        .capital {
            text-transform: uppercase;
        }

        .justify {
            text-align: justify;
        }

        .top {
            width: 100%;
            margin: auto;
            background: #912890;
        }

        .one {
            width: 70%;
            height: 22px;
            background: #292983;
            float: left;
        }

        .two {
            margin-left: 15%;
            height: 22px;
            background: #912890;
        }

        .qr {
            width: 100px;
        }
    </style>
</head>


<body>
    <section class="top">
        <div class="one"></div>
        <div class="two"></div>
    </section>
    <br />
    <div class="right">
        <?php echo $this->Html->image('../img/surat/LogoUiTM.png', ['width' => '180px', 'fullBase' => true]) ?>
    </div>
    <br />

    <div class="content">
        <table width="320px" align="right">
            <tr>
                <td width="70px">Surat Kami</td>
                <td>:</td>
                        <td>
                            <?php if ($application->status == 0) {
                                echo '-';
                            } elseif ($application->status == 1) {
                                echo $application->ref_no;
                            } else
                                echo 'Rejected';
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <td class="text-end">Tarikh &nbsp;: &nbsp;</td>
                        <td>
                            <?php if ($application->status == 0) {
                                echo '-';
                            } elseif ($application->status == 1) {
                                echo date('d F Y', strtotime($application->created));
                            } else
                                echo 'Rejected';
                            ?>
                        </td>
                    </tr>
                </table>

                <?php echo $application->lecturer->name; ?><br/>
                Pensyarah<br/>
                Fakulti Sains Maklumat</br>
                UiTM Cawangan Selangor Kampus Puncak Perdana<br/>
                Jalan Pulau Indah Au10/A, Puncak Perdana, <br/>
                40150 Shah Alam, <br/>
                <strong>Selangor</strong>

                <br /><br />
                <b>Untuk Perhatian: <?= h($application->approval_name) ?></b>
                <br /><br />
                Tuan/Puan
                <br /><br />
                <strong>PERMOHONAN DANA PENYELIDIKAN</strong>
                <br /><br />
                <table class="table table-bordered table-sm table_transparent capital">
                    <tr>
                        <td>NAMA PENSYARAH</td>
                        <td>:</td>
                        <td><?= $application->lecturer->name ?></td>
                    </tr>
                    <tr>
                        <td>PROJEK</td>
                        <td>:</td>
                        <td><?= $application->title ?></td>
                    </tr>
                    <tr>
                        <td>BAJET</td>
                        <td>:</td>
                        <td><?= $application->budget ?></td>
                    </tr>
                    <tr>
                        <td>AHLI PERTAMA</td>
                        <td>:</td>
                        <td><?= h($application->member_1) ?></td>
                    </tr>
                    <tr>
                        <td>AHLI KEDUA</td>
                        <td>:</td>
                        <td><?= h($application->member_2) ?></td>
                    </tr>
                    <tr>
                        <td>AHLI KETIGA</td>
                        <td>:</td>
                        <td><?= h($application->member_3) ?></td>
                    </tr>
                    <tr>
                        <td>AHLI KEEMPAT</td>
                        <td>:</td>
                        <td><?= h($application->member_4) ?></td>
                    </tr>
                    <tr>
                        <td>AHLI KELIMA</td>
                        <td>:</td>
                        <td><?= h($application->member_5) ?></td>
                    </tr>
                </table>
                <br />
                <div class="justify">
                    Dengan segala hormatnya perkara di atas adalah dirujuk.
                    <br><br>
                    2.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sukacita dimaklumkan bahawa saya, <?= $application->lecturer->name ?> dari Fakulti Sains Maklumat, ingin memohon dana penyelidikan bagi melaksanakan projek bertajuk:
                    <br><br>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?= $application->title ?>
                    <br><br>
                    3.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Penyelidikan ini bertujuan untuk menjalankan penyelidikan yang menyumbang kepada penambahan ilmu baharu dalam bidang sains maklumat. Kajian ini dijangka akan memberi sumbangan kepada bidang Fakulti Sains Maklumat serta menyokong agenda penyelidikan universiti.
                    <br><br>
                    Bersama-sama ini saya sertakan:
                    <ol type="a">
                        <li>&nbsp;&nbsp;&nbsp;&nbsp;Kertas cadangan penyelidikan</li>
                        <li>&nbsp;&nbsp;&nbsp;&nbsp;Anggaran bajet keseluruhan</li>
                        <li>&nbsp;&nbsp;&nbsp;&nbsp;Nama-nama ahli penyelidik</li>
                    </ol>
                    4.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Sehubungan itu, saya memohon pertimbangan pihak tuan/puan untuk meluluskan permohonan dana sebanyak RM <?= $application->budget ?> bagi tujuan penyelidikan ini. Peruntukan tersebut akan digunakan bagi perbelanjaan seperti pembelian bahan, perisian, data, upah penyelidik pembantu dan perjalanan.
                    <br><br>
                    5.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Kerjasama dan pertimbangan pihak tuan/puan amat dihargai dan didahului dengan ucapan terima kasih.
                    <br><br>

                    <table width="100%">
                <tr>
                    <td width="85%" style="vertical-align: top;">
                        Sekian, terima kasih.
                        <br><br>
                        Jabatan Hal Ehwal Akademik, UiTM
                        <br><br>
                        <strong>CETAKAN BERKOMPUTER. TIDAK PERLU TANDATANGAN.</strong>
                    </td>
                </tr>
            </table>
        </div>
    </div>

    <div class="right">
        <?php echo $this->Html->image('../img/surat/ISO.png', ['width' => '150px', 'fullBase' => true]) ?><br />
        <?php echo $this->Html->image('../img/surat/uitmdihatiku.png', ['width' => '150px', 'fullBase' => true]) ?>
    </div>
</body>

</html>