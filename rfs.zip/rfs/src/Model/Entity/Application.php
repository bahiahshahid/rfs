<?php
declare(strict_types=1);

namespace App\Model\Entity;

use Cake\ORM\Entity;

/**
 * Application Entity
 *
 * @property int $id
 * @property int $lecturer_id
 * @property string $title
 * @property int $budget
 * @property \Cake\I18n\Date $start_date
 * @property \Cake\I18n\Date $end_date
 * @property string $abstract
 * @property string $literature_review
 * @property string $member_1
 * @property string $member_2
 * @property string $member_3
 * @property string $member_4
 * @property string $member_5
 * @property string $approval_name
 * @property string $approval_post
 * @property \Cake\I18n\Date $approval_date
 * @property int $status
 * @property \Cake\I18n\Date $application_date
 * @property \Cake\I18n\DateTime $created
 * @property \Cake\I18n\DateTime $modified
 *
 * @property \App\Model\Entity\Lecturer $lecturer
 */
class Application extends Entity
{
    /**
     * Fields that can be mass assigned using newEntity() or patchEntity().
     *
     * Note that when '*' is set to true, this allows all unspecified fields to
     * be mass assigned. For security purposes, it is advised to set '*' to false
     * (or remove it), and explicitly make individual fields accessible as needed.
     *
     * @var array<string, bool>
     */
    protected array $_accessible = [
        'lecturer_id' => true,
        'title' => true,
        'budget' => true,
        'start_date' => true,
        'end_date' => true,
        'abstract' => true,
        'literature_review' => true,
        'member_1' => true,
        'member_2' => true,
        'member_3' => true,
        'member_4' => true,
        'member_5' => true,
        'approval_name' => true,
        'approval_post' => true,
        'approval_date' => true,
        'status' => true,
        'application_date' => true,
        'created' => true,
        'modified' => true,
        'lecturer' => true,
    ];
}
