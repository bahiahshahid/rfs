<?php
declare(strict_types=1);

namespace App\Model\Table;

use Cake\ORM\Query\SelectQuery;
use Cake\ORM\RulesChecker;
use Cake\ORM\Table;
use Cake\Validation\Validator;

/**
 * Applications Model
 *
 * @property \App\Model\Table\LecturersTable&\Cake\ORM\Association\BelongsTo $Lecturers
 *
 * @method \App\Model\Entity\Application newEmptyEntity()
 * @method \App\Model\Entity\Application newEntity(array $data, array $options = [])
 * @method array<\App\Model\Entity\Application> newEntities(array $data, array $options = [])
 * @method \App\Model\Entity\Application get(mixed $primaryKey, array|string $finder = 'all', \Psr\SimpleCache\CacheInterface|string|null $cache = null, \Closure|string|null $cacheKey = null, mixed ...$args)
 * @method \App\Model\Entity\Application findOrCreate($search, ?callable $callback = null, array $options = [])
 * @method \App\Model\Entity\Application patchEntity(\Cake\Datasource\EntityInterface $entity, array $data, array $options = [])
 * @method array<\App\Model\Entity\Application> patchEntities(iterable $entities, array $data, array $options = [])
 * @method \App\Model\Entity\Application|false save(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method \App\Model\Entity\Application saveOrFail(\Cake\Datasource\EntityInterface $entity, array $options = [])
 * @method iterable<\App\Model\Entity\Application>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Application>|false saveMany(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Application>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Application> saveManyOrFail(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Application>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Application>|false deleteMany(iterable $entities, array $options = [])
 * @method iterable<\App\Model\Entity\Application>|\Cake\Datasource\ResultSetInterface<\App\Model\Entity\Application> deleteManyOrFail(iterable $entities, array $options = [])
 *
 * @mixin \Cake\ORM\Behavior\TimestampBehavior
 */
class ApplicationsTable extends Table
{
    /**
     * Initialize method
     *
     * @param array<string, mixed> $config The configuration for the Table.
     * @return void
     */
    public function initialize(array $config): void
    {
        parent::initialize($config);

        $this->setTable('applications');
        $this->setDisplayField('title');
        $this->setPrimaryKey('id');

        $this->addBehavior('Timestamp');

        $this->belongsTo('Lecturers', [
            'foreignKey' => 'lecturer_id',
            'joinType' => 'INNER',
        ]);
		$this->addBehavior('AuditStash.AuditLog');

        $this->addBehavior('Josegonzalez/Upload.Upload', [
            'literature_review' => [
                'fields' => [],
            ],
        ]);




		$this->addBehavior('Search.Search');
		$this->searchManager()
			->value('id')
				->add('search', 'Search.Like', [
					//'before' => true,
					//'after' => true,
					'fieldMode' => 'OR',
					'multiValue' => true,
					'multiValueSeparator' => '|',
					'comparison' => 'LIKE',
					'wildcardAny' => '*',
					'wildcardOne' => '?',
					'fields' => ['id'],
				]);
    }

    /**
     * Default validation rules.
     *
     * @param \Cake\Validation\Validator $validator Validator instance.
     * @return \Cake\Validation\Validator
     */
    public function validationDefault(Validator $validator): Validator
    {
        $validator
            ->integer('lecturer_id')
            ->notEmptyString('lecturer_id');

        $validator
            ->scalar('title')
            ->maxLength('title', 255)
            ->requirePresence('title', 'create')
            ->notEmptyString('title');

        $validator
            ->integer('budget')
            ->requirePresence('budget', 'create')
            ->notEmptyString('budget');

        $validator
            ->date('start_date')
            ->requirePresence('start_date', 'create')
            ->notEmptyDateTime('start_date');

        $validator
            ->date('end_date')
            ->requirePresence('end_date', 'create')
            ->notEmptyDateTime('end_date');

        $validator
            ->scalar('abstract')
            ->maxLength('abstract', 255)
            ->requirePresence('abstract', 'create')
            ->notEmptyString('abstract');

        $validator
            ->allowEmptyFile('literature_review')
            ->add('literature_review', [
                'validExtension' => [
                'rule' => ['extension', ['pdf']],
                'message'=> ('Only .pdf are allowed')
                ]
            ]);

        $validator
            ->scalar('member_1')
            ->maxLength('member_1', 255)
            ->requirePresence('member_1', 'create')
            ->notEmptyString('member_1');

        $validator
            ->scalar('member_2')
            ->maxLength('member_2', 255)
            ->requirePresence('member_2', 'create')
            ->notEmptyString('member_2');

        $validator
            ->scalar('member_3')
            ->maxLength('member_3', 255)
            ->requirePresence('member_3', 'create')
            ->notEmptyString('member_3');

        $validator
            ->scalar('member_4')
            ->maxLength('member_4', 255)
            ->requirePresence('member_4', 'create')
            ->notEmptyString('member_4');

        $validator
            ->scalar('member_5')
            ->maxLength('member_5', 255)
            ->requirePresence('member_5', 'create')
            ->notEmptyString('member_5');

        $validator
            ->scalar('approval_name')
            ->maxLength('approval_name', 255)
            ->requirePresence('approval_name', 'create')
            ->allowEmptyString('approval_name'); 

        $validator
            ->scalar('approval_post')
            ->maxLength('approval_post', 255)
            ->requirePresence('approval_post', 'create')
            ->allowEmptyString('approval_post');

        $validator
            ->date('approval_date')
            ->requirePresence('approval_date', 'create')
            ->allowEmptyDate('approval_date');

        $validator
            ->integer('status')
            ->allowEmptyString('status');

        $validator
            ->date('application_date')
            ->requirePresence('application_date', 'create')
            ->notEmptyDate('application_date');

        return $validator;
    }

    /**
     * Returns a rules checker object that will be used for validating
     * application integrity.
     *
     * @param \Cake\ORM\RulesChecker $rules The rules object to be modified.
     * @return \Cake\ORM\RulesChecker
     */
    public function buildRules(RulesChecker $rules): RulesChecker
    {
        $rules->add($rules->existsIn(['lecturer_id'], 'Lecturers'), ['errorField' => 'lecturer_id']);

        return $rules;
    }
}
